const alunoControlador = new AlunoControlador();
